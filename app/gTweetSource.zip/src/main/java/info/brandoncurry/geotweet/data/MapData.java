package info.brandoncurry.geotweet.data;

import java.util.ArrayList;

import info.brandoncurry.geotweet.model.Tweet;

/**
 * Created by brandon.curry on 12/15/15.
 */
public class MapData
{
    public static ArrayList<Tweet> mapTweets = new ArrayList<Tweet>();

    public MapData()
    {

    }
}
